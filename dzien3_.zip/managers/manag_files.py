class FileManager:
    def __init__(self, file_name: str, mode: str):
        self.file_name = file_name
        self.mode = mode
        self.file = None

    def __enter__(self):
        # Otwiera plik i zwraca obiekt pliku
        self.file = open(self.file_name, self.mode)
        return self.file

    def __exit__(self, exc_type, exc_value, traceback):
        # Zamknięcie pliku
        if self.file:
            self.file.close()

# Użycie menedżera kontekstu
with FileManager("example.txt", "w") as file:
    file.write("Hello, World!")
    file.write("\nTo jest przykład menedżera kontekstu.")

# Po wyjściu z bloku `with`, plik zostanie automatycznie zamknięty.
