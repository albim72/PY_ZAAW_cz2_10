import logging
from contextlib import contextmanager

# Konfiguracja loggera
logging.basicConfig(level=logging.ERROR, filename='db_errors.log')

class DatabaseConnection:
    def __init__(self, db_name: str):
        self.db_name = db_name
        self.connection = None

    def __enter__(self):
        # Symulacja nawiązywania połączenia z bazą danych
        print(f"Nawiązywanie połączenia z bazą danych: {self.db_name}")
        self.connection = f"Connection to {self.db_name}"
        return self.connection

    def __exit__(self, exc_type, exc_value, traceback):
        # Sprawdzenie, czy wystąpił wyjątek
        if exc_type is not None:
            logging.error(f"Wystąpił błąd: {exc_value}")
            print(f"Wystąpił błąd przy pracy z bazą danych: {exc_value}")
        # Symulacja zamykania połączenia
        print(f"Zamykanie połączenia z bazą danych: {self.db_name}")
        self.connection = None

# Użycie menedżera kontekstu z logowaniem błędów
def execute_query(query: str):
    with DatabaseConnection("my_database") as conn:
        if query.lower() == "fail":
            raise ValueError("Symulowany błąd zapytania.")
        print(f"Wykonywanie zapytania: {query} na {conn}")

# Przykładowe wywołania
try:
    execute_query("SELECT * FROM users")
    execute_query("fail")  # To zapytanie spowoduje błąd
except Exception as e:
    print(f"Obsługiwany błąd: {e}")
