import example

print(example.cython_sum(1000000))

#cythonize -i example.pyx
