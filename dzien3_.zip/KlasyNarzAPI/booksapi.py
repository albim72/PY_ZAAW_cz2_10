from flask import Flask, jsonify, request

app = Flask(__name__)

# Lokalna "baza danych" - lista książek
books = [
    {"id": 1, "title": "Wiedźmin: Ostatnie Życzenie", "author": "Andrzej Sapkowski"},
    {"id": 2, "title": "Harry Potter i Kamień Filozoficzny", "author": "J.K. Rowling"},
]


# Endpoint do pobrania wszystkich książek
@app.route('/books', methods=['GET'])
def get_books():
    return jsonify(books)


# Endpoint do pobrania konkretnej książki po ID
@app.route('/books/<int:book_id>', methods=['GET'])
def get_book(book_id):
    book = next((book for book in books if book["id"] == book_id), None)
    if book is None:
        return jsonify({"error": "Book not found"}), 404
    return jsonify(book)


# Endpoint do dodania nowej książki
@app.route('/books', methods=['POST'])
def add_book():
    new_book = request.get_json()
    new_book["id"] = len(books) + 1
    books.append(new_book)
    return jsonify(new_book), 201


# Endpoint do aktualizacji danych książki
@app.route('/books/<int:book_id>', methods=['PUT'])
def update_book(book_id):
    book = next((book for book in books if book["id"] == book_id), None)
    if book is None:
        return jsonify({"error": "Book not found"}), 404

    updated_data = request.get_json()
    book.update(updated_data)
    return jsonify(book)


# Endpoint do usunięcia książki
@app.route('/books/<int:book_id>', methods=['DELETE'])
def delete_book(book_id):
    global books
    books = [book for book in books if book["id"] != book_id]
    return jsonify({"message": "Book deleted"}), 200


if __name__ == '__main__':
    app.run(debug=True)
