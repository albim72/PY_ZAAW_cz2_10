from line_profiler import LineProfiler

def test_function():
    total = 0
    for i in range(1, 10000):
        total += i ** 2
    return total

profiler = LineProfiler()
profiler.add_function(test_function)
profiler.run('test_function()')

# Wyświetlanie wyników
profiler.print_stats()
