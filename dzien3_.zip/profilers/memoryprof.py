import memory_profiler

@profile
def test_memory_function():
    a = [i for i in range(100000)]
    return a

test_memory_function()
