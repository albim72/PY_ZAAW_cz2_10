import asyncio
import time


async def async_task(name, duration):
    print(f'Task {name} starting')
    await asyncio.sleep(duration)
    print(f'Task {name} completed after {duration} seconds')


async def main():
    # Tworzenie zadań
    tasks = [
        async_task('A', 2),
        async_task('B', 1),
        async_task('C', 3)
    ]

    # Uruchamianie zadań współbieżnie
    await asyncio.gather(*tasks)


# Uruchomienie pętli zdarzeń
start_time = time.time()
asyncio.run(main())
end_time = time.time()

print(f'Total time: {end_time - start_time} seconds')
